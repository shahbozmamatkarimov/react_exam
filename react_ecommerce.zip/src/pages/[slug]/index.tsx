import Cards from "../../components/Card";
import Slug from "../../components/slug/Slug";
export default function Home() {
  return (
    <>
      <Slug />
    </>
  );
}
